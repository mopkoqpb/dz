a = 1
b = 2.0
c = True
d = 'privet'

a = str(a)
b = str(b)